# Xenoverse PT-BR Android App v1.0

Aplicativo Android para gerar e instalar uma tradução PT-BR do Pokémon Xenoverse sem Termux.

## O que ele faz

- Seleciona a pasta principal do Xenoverse pelo seletor de pastas do Android.
- Lê `Data/english.txt` da própria cópia do usuário.
- Traduz história, NPCs, menus, tutoriais, descrições e mensagens.
- Mantém em inglês: Moves, Pokémon, Abilities, Items, Types, classes/nomes de treinadores, locais e outros termos importantes.
- Preserva controles e placeholders como `\PN`, `\v[1]`, `<<n>>`, tags e variáveis.
- Salva `Data/ptbr_translation_cache.json`, então uma tradução interrompida pode continuar.
- Cria `Data/portuguese.txt`.
- Faz backup de `Data/Scripts.xvd` em `Data/Scripts.xvd.ptbr-backup`.
- Adiciona `Português (Brasil)` ao seletor do jogo.
- Injeta um pequeno compilador Ruby no `Settings` do próprio jogo; na primeira abertura, o Xenoverse gera `Data/portuguese.dat`.

## Uso

1. Instale o APK.
2. Toque em **Selecionar pasta do Xenoverse** e escolha a pasta que contém `Data`.
3. Toque em **Traduzir e instalar PT-BR**.
4. Mantenha internet disponível. Você pode sair do app; ele usa serviço em primeiro plano.
5. Quando terminar, abra o Xenoverse e escolha **Português (Brasil)**.

A tradução completa pode levar um tempo porque existem milhares de mensagens únicas. O cache permite continuar depois.

## Compilar o APK no GitHub sem Termux

O workflow `.github/workflows/build-apk.yml` já está incluído.

1. Crie um repositório no GitHub e envie esta pasta.
2. Abra **Actions** > **Build Android APK**.
3. Rode **Run workflow**.
4. Baixe o artifact **Xenoverse-PTBR-APK**.
5. Dentro dele estará `app-debug.apk`.

## Observação

O app usa o endpoint público de tradução usado pelo builder anterior. Ele pode sofrer limite temporário de rede. Em caso de falha, o cache preserva o progresso já feito.
