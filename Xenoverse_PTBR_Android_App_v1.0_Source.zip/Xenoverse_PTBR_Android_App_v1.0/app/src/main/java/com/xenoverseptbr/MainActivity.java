package com.xenoverseptbr;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private static final int REQ_NOTIFICATIONS = 1002;

    private TextView folderStatus, progressText, detailText;
    private ProgressBar progress;
    private Button selectFolder, startTranslation, cancelTranslation;
    private Uri gameTree;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver progressReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TranslationService.ACTION_PROGRESS.equals(intent.getAction())) return;
            int pct = intent.getIntExtra("percent", 0);
            String status = intent.getStringExtra("status");
            String detail = intent.getStringExtra("detail");
            boolean running = intent.getBooleanExtra("running", false);

            progress.setProgress(pct);
            if (status != null) progressText.setText(status);
            if (detail != null && !detail.isEmpty()) detailText.setText(detail);
            startTranslation.setEnabled(gameTree != null && !running);
            cancelTranslation.setEnabled(running);
            selectFolder.setEnabled(!running);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        folderStatus = findViewById(R.id.folderStatus);
        progressText = findViewById(R.id.progressText);
        detailText = findViewById(R.id.detailText);
        progress = findViewById(R.id.progress);
        selectFolder = findViewById(R.id.selectFolder);
        startTranslation = findViewById(R.id.startTranslation);
        cancelTranslation = findViewById(R.id.cancelTranslation);

        SharedPreferences p = getSharedPreferences("prefs", MODE_PRIVATE);
        String saved = p.getString("gameTree", null);
        if (saved != null) {
            try {
                gameTree = Uri.parse(saved);
                folderStatus.setText("Pasta salva:\n" + gameTree);
                startTranslation.setEnabled(true);
            } catch (Exception ignored) {}
        }

        selectFolder.setOnClickListener(v -> chooseFolder());
        startTranslation.setOnClickListener(v -> startTranslation());
        cancelTranslation.setOnClickListener(v -> {
            Intent i = new Intent(this, TranslationService.class);
            i.setAction(TranslationService.ACTION_CANCEL);
            startService(i);
        });

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, PICK_TREE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {}

        gameTree = uri;
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putString("gameTree", uri.toString()).apply();

        try {
            SafFiles.GameFiles gf = SafFiles.locateGameFiles(getContentResolver(), uri);
            folderStatus.setText("Xenoverse encontrado.\nData/english.txt: OK\nData/Scripts.xvd: " +
                    (gf.scriptsXvd != null ? "OK" : "não encontrado"));
            startTranslation.setEnabled(true);
        } catch (Exception e) {
            folderStatus.setText("Essa pasta não parece ser a pasta principal do Xenoverse.\n" + e.getMessage());
            startTranslation.setEnabled(false);
        }
    }

    private void startTranslation() {
        if (gameTree == null) return;
        Intent i = new Intent(this, TranslationService.class);
        i.setAction(TranslationService.ACTION_START);
        i.putExtra("treeUri", gameTree.toString());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter(TranslationService.ACTION_PROGRESS);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(progressReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(progressReceiver, f);
        }
        receiverRegistered = true;
    }

    @Override protected void onStop() {
        super.onStop();
        if (receiverRegistered) {
            unregisterReceiver(progressReceiver);
            receiverRegistered = false;
        }
    }
}
