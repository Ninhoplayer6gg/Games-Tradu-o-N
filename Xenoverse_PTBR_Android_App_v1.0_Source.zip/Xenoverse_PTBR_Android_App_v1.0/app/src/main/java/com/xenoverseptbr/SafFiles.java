package com.xenoverseptbr;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class SafFiles {
    private SafFiles() {}

    public static final class GameFiles {
        public final Uri root;
        public final Uri dataDir;
        public final Uri englishTxt;
        public final Uri scriptsXvd;
        GameFiles(Uri root, Uri dataDir, Uri englishTxt, Uri scriptsXvd) {
            this.root = root; this.dataDir = dataDir; this.englishTxt = englishTxt; this.scriptsXvd = scriptsXvd;
        }
    }

    public static Uri rootDocument(Uri treeUri) {
        String id = DocumentsContract.getTreeDocumentId(treeUri);
        return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
    }

    public static Uri findChild(ContentResolver cr, Uri treeUri, Uri parent, String name) throws Exception {
        String parentId = DocumentsContract.getDocumentId(parent);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId);
        String[] projection = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
        };
        try (Cursor c = cr.query(children, projection, null, null, null)) {
            if (c == null) return null;
            int idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            while (c.moveToNext()) {
                if (name.equals(c.getString(nameCol))) {
                    return DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(idCol));
                }
            }
        }
        return null;
    }

    public static GameFiles locateGameFiles(ContentResolver cr, Uri treeUri) throws Exception {
        Uri root = rootDocument(treeUri);
        Uri data = findChild(cr, treeUri, root, "Data");
        if (data == null) throw new Exception("Não encontrei a pasta Data.");
        Uri english = findChild(cr, treeUri, data, "english.txt");
        if (english == null) throw new Exception("Não encontrei Data/english.txt.");
        Uri scripts = findChild(cr, treeUri, data, "Scripts.xvd");
        return new GameFiles(root, data, english, scripts);
    }

    public static byte[] readBytes(ContentResolver cr, Uri uri) throws Exception {
        try (InputStream in = cr.openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Não foi possível abrir " + uri);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    public static String readText(ContentResolver cr, Uri uri) throws Exception {
        byte[] b = readBytes(cr, uri);
        String s = new String(b, StandardCharsets.UTF_8);
        if (!s.isEmpty() && s.charAt(0) == '\uFEFF') s = s.substring(1);
        return s;
    }

    public static Uri getOrCreate(ContentResolver cr, Uri treeUri, Uri parent, String mime, String name) throws Exception {
        Uri existing = findChild(cr, treeUri, parent, name);
        if (existing != null) return existing;
        Uri created = DocumentsContract.createDocument(cr, parent, mime, name);
        if (created == null) throw new Exception("Não consegui criar " + name);
        return created;
    }

    public static void writeBytes(ContentResolver cr, Uri uri, byte[] data) throws Exception {
        try (OutputStream out = cr.openOutputStream(uri, "wt")) {
            if (out == null) throw new Exception("Não foi possível gravar " + uri);
            out.write(data);
            out.flush();
        }
    }

    public static void writeText(ContentResolver cr, Uri uri, String text) throws Exception {
        writeBytes(cr, uri, text.getBytes(StandardCharsets.UTF_8));
    }

    public static void copy(ContentResolver cr, Uri src, Uri dst) throws Exception {
        writeBytes(cr, dst, readBytes(cr, src));
    }
}
