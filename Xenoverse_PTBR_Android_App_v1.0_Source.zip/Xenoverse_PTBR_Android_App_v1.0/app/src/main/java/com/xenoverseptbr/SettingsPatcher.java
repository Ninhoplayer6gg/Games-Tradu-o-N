package com.xenoverseptbr;

import android.content.Context;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public final class SettingsPatcher {
    private SettingsPatcher() {}

    private static final class Fx {
        final int value, next;
        Fx(int value, int next) { this.value=value; this.next=next; }
    }

    public static byte[] patch(Context context, byte[] marshal) throws Exception {
        if (marshal.length < 16 || marshal[0] != 4 || marshal[1] != 8)
            throw new Exception("Scripts.xvd não parece ser um Ruby Marshal compatível.");

        int p = 2;
        if (marshal[p++] != '[') throw new Exception("Estrutura inesperada em Scripts.xvd.");
        Fx top = readFixnum(marshal,p); p=top.next;
        if (marshal[p++] != '[') throw new Exception("Primeiro script não é uma entrada válida.");
        Fx entryLen=readFixnum(marshal,p); p=entryLen.next;
        if (entryLen.value != 3) throw new Exception("Entrada Settings inesperada.");

        if (marshal[p++] != 'i') throw new Exception("ID do Settings inválido.");
        Fx id=readFixnum(marshal,p); p=id.next;

        String name;
        if (marshal[p] == 'I') {
            p++;
            if (marshal[p++] != '"') throw new Exception("Nome do script inválido.");
            Fx len=readFixnum(marshal,p); p=len.next;
            name = new String(marshal,p,len.value,StandardCharsets.UTF_8); p += len.value;
            Fx count=readFixnum(marshal,p); p=count.next;
            for (int n=0;n<count.value;n++) {
                p = skipSimpleObject(marshal,p); // chave do IVAR, ex.: :E
                p = skipSimpleObject(marshal,p); // valor do IVAR, ex.: true
            }
        } else if (marshal[p] == '"') {
            p++;
            Fx len=readFixnum(marshal,p); p=len.next;
            name = new String(marshal,p,len.value,StandardCharsets.UTF_8); p += len.value;
        } else throw new Exception("Não consegui ler o nome do Settings.");

        if (!"Settings".equals(name))
            throw new Exception("Esta versão do Scripts.xvd não tem Settings como primeiro script.");

        int dataTag = p;
        if (marshal[p++] != '"') throw new Exception("Dados comprimidos do Settings inválidos.");
        Fx dl = readFixnum(marshal,p);
        int oldDataStart = dl.next;
        int oldDataEnd = oldDataStart + dl.value;
        if (oldDataEnd > marshal.length) throw new Exception("Scripts.xvd truncado.");

        byte[] compressed = Arrays.copyOfRange(marshal, oldDataStart, oldDataEnd);
        byte[] encoded = inflate(compressed);
        byte[] sourceBytes = Base64.decode(encoded, Base64.DEFAULT);
        String source = new String(sourceBytes, StandardCharsets.UTF_8);

        if (!source.contains("Português (Brasil)")) {
            String needle = "  [\"English\",\"english.dat\"],";
            if (!source.contains(needle)) throw new Exception("Não encontrei English/english.dat em Settings.");
            source = source.replace(needle, needle + "\r\n  [\"Português (Brasil)\",\"portuguese.dat\"],");
        }

        if (!source.contains("XENOVERSE_PTBR_AUTOCOMPILER_V1")) {
            String compiler = readRaw(context, R.raw.ptbr_compiler);
            String marker = "LANGUAGES = [";
            int at = source.indexOf(marker);
            if (at < 0) throw new Exception("Não encontrei LANGUAGES em Settings.");
            source = source.substring(0, at) + compiler + "\r\n\r\n" + source.substring(at);
        }

        byte[] newEncoded = Base64.encode(source.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        byte[] newCompressed = deflate(newEncoded);
        byte[] lenBytes = writeFixnum(newCompressed.length);

        ByteArrayOutputStream out = new ByteArrayOutputStream(marshal.length + newCompressed.length);
        out.write(marshal, 0, dataTag + 1); // inclui a tag de String
        out.write(lenBytes);
        out.write(newCompressed);
        out.write(marshal, oldDataEnd, marshal.length - oldDataEnd);
        return out.toByteArray();
    }

    private static int skipSimpleObject(byte[] b, int p) throws Exception {
        int tag = b[p++] & 0xFF;
        if (tag == ':') { Fx l=readFixnum(b,p); return l.next + l.value; }
        if (tag == 'T' || tag == 'F' || tag == '0') return p;
        if (tag == 'i') return readFixnum(b,p).next;
        if (tag == '"') { Fx l=readFixnum(b,p); return l.next+l.value; }
        throw new Exception("IVAR inesperado em Settings: " + tag);
    }

    private static Fx readFixnum(byte[] b, int p) throws Exception {
        int c = b[p++];
        if (c == 0) return new Fx(0,p);
        if (c >= 5 && c <= 127) return new Fx(c-5,p);
        if (c <= -5) return new Fx(c+5,p);
        int n = Math.abs(c);
        if (n < 1 || n > 4 || p+n > b.length) throw new Exception("Fixnum inválido.");
        int v = c > 0 ? 0 : -1;
        if (c > 0) {
            for (int i=0;i<n;i++) v |= (b[p+i]&0xFF) << (8*i);
        } else {
            for (int i=0;i<n;i++) {
                v &= ~(0xFF << (8*i));
                v |= (b[p+i]&0xFF) << (8*i);
            }
        }
        return new Fx(v,p+n);
    }

    private static byte[] writeFixnum(int value) {
        if (value == 0) return new byte[]{0};
        if (value > 0 && value < 123) return new byte[]{(byte)(value+5)};
        int n=1;
        while ((value >>> (8*n)) != 0 && n < 4) n++;
        byte[] out = new byte[n+1];
        out[0]=(byte)n;
        for (int i=0;i<n;i++) out[i+1]=(byte)((value >>> (8*i)) & 0xFF);
        return out;
    }

    private static byte[] inflate(byte[] data) throws Exception {
        Inflater inf = new Inflater();
        inf.setInput(data);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        while (!inf.finished()) {
            int n=inf.inflate(buf);
            if (n==0 && inf.needsInput()) break;
            out.write(buf,0,n);
        }
        inf.end();
        return out.toByteArray();
    }

    private static byte[] deflate(byte[] data) throws Exception {
        Deflater def = new Deflater(Deflater.DEFAULT_COMPRESSION);
        def.setInput(data);
        def.finish();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        while (!def.finished()) out.write(buf,0,def.deflate(buf));
        def.end();
        return out.toByteArray();
    }

    private static String readRaw(Context context, int id) throws Exception {
        try (java.io.InputStream in = context.getResources().openRawResource(id);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n; while ((n=in.read(buf))>=0) out.write(buf,0,n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
}
