package com.xenoverseptbr;

import android.content.ContentResolver;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TranslationEngine {
    private TranslationEngine() {}

    public interface Callback {
        void onProgress(int done, int total, String message) throws Exception;
        boolean isCancelled();
    }

    private static final String ENDPOINT = "https://translate.googleapis.com/translate_a/single";

    private static final Set<String> KEEP_SECTIONS = new HashSet<>(Arrays.asList(
            "1","4","5","7","9","11","12","13","18","19","20"
    ));

    private static final Map<String,String> EXACT = new HashMap<>();
    private static final Map<String,String> CASUAL = new HashMap<>();
    static {
        EXACT.put("Yes","Sim"); EXACT.put("No","Não"); EXACT.put("Quit","Sair");
        EXACT.put("Exit","Sair"); EXACT.put("Back","Voltar"); EXACT.put("Cancel","Cancelar");
        EXACT.put("Confirm","Confirmar"); EXACT.put("New Game","Novo Jogo");
        EXACT.put("Continue","Continuar"); EXACT.put("Settings","Configurações");
        EXACT.put("Options","Opções"); EXACT.put("Save","Salvar"); EXACT.put("Load","Carregar");
        EXACT.put("Language","Idioma"); EXACT.put("Choose a language.","Escolha um idioma.");
        EXACT.put("Heal Pokémon","Curar Pokémon"); EXACT.put("Use Box","Usar Box");
        EXACT.put("Move Pokémon","Mover Pokémon"); EXACT.put("Withdraw","Retirar");
        EXACT.put("Deposit","Depositar"); EXACT.put("Organize Boxes","Organizar Boxes");
        EXACT.put("Evaluate Pokédex","Avaliar Pokédex");
        EXACT.put("Pokédex","Pokédex"); EXACT.put("Pokémon","Pokémon");
        EXACT.put("Poké Balls","Poké Balls"); EXACT.put("TMs & HMs","TMs & HMs");
        EXACT.put("Key Items","Key Items"); EXACT.put("Battle Items","Battle Items");
        EXACT.put("Items","Items"); EXACT.put("Item","Item"); EXACT.put("Moves","Moves");
        EXACT.put("Move","Move"); EXACT.put("Abilities","Abilities"); EXACT.put("Ability","Ability");
        EXACT.put("Types","Types"); EXACT.put("Type","Type"); EXACT.put("Trainer","Trainer");
        EXACT.put("Level","Level"); EXACT.put("HP","HP"); EXACT.put("Attack","Attack");
        EXACT.put("Defense","Defense"); EXACT.put("Speed","Speed");

        CASUAL.put("Come on, guys!","Bora, pessoal!");
        CASUAL.put("Come on!","Bora!");
        CASUAL.put("Hey there!","E aí!");
        CASUAL.put("Thanks!","Valeu!");
        CASUAL.put("Thank you!","Valeu!");
        CASUAL.put("Damn it!","Droga!");
    }

    private static final Pattern SECTION = Pattern.compile("^\\[([^\\]]+)]$");
    private static final Pattern WORDISH = Pattern.compile("[A-Za-zÀ-ÿ]");
    private static final Pattern SENTENCE = Pattern.compile(
            "[.!?…,:;]|\\b(?:the|a|an|is|are|was|were|you|your|my|we|our|to|of|and|or|in|on|for|with|this|that|do|does|did|can|will|would|have|has|had|it|they|he|she|i)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern CONTROL = Pattern.compile(
            "(?:<<[^>]*>>)|(?:\\\\[A-Za-z]+(?:\\[[^\\]]*])?)|(?:\\\\[nrtm])|(?:\\{[^{}]*})|(?:%\\d*\\$?[sdif])|(?:<[^>]+>)");
    private static final Pattern BOLD = Pattern.compile("<b>(.*?)</b>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    public static final class Result {
        public final String portugueseText;
        public final JSONObject cache;
        Result(String portugueseText, JSONObject cache) {
            this.portugueseText = portugueseText;
            this.cache = cache;
        }
    }

    private static final class Entry {
        final String sec; final int source; final int target;
        Entry(String sec, int source, int target) { this.sec=sec; this.source=source; this.target=target; }
    }

    private static List<Entry> parseEntries(List<String> lines) {
        List<Entry> out = new ArrayList<>();
        String section = null;
        List<Integer> buf = new ArrayList<>();

        for (int i=0; i<=lines.size(); i++) {
            String s = (i < lines.size()) ? lines.get(i).trim() : "[__END__]";
            Matcher m = SECTION.matcher(s);
            if (m.matches()) {
                if (section != null && !buf.isEmpty()) {
                    if (section.matches("\\d+") && lines.get(buf.get(0)).trim().matches("\\d+")) {
                        for (int k=0; k+2<buf.size(); k+=3)
                            out.add(new Entry(section, buf.get(k+1), buf.get(k+2)));
                    } else {
                        for (int k=0; k+1<buf.size(); k+=2)
                            out.add(new Entry(section, buf.get(k), buf.get(k+1)));
                    }
                }
                section = m.group(1);
                buf.clear();
                continue;
            }
            if (section == null || s.isEmpty() || s.startsWith("#")) continue;
            buf.add(i);
        }
        return out;
    }

    private static boolean probableNameOnly(String text) {
        String s = text.replaceAll("<[^>]+>", "").replaceAll("<<[^>]*>>", "")
                .replaceAll("\\\\[A-Za-z]+(?:\\[[^\\]]*])?", "").trim();
        if (s.isEmpty() || s.length() > 55 || SENTENCE.matcher(s).find()) return false;
        Matcher m = Pattern.compile("[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’.-]*").matcher(s);
        List<String> words = new ArrayList<>();
        while (m.find()) words.add(m.group());
        if (words.isEmpty() || words.size() > 4) return false;
        for (String w : words) {
            String low = w.toLowerCase(Locale.ROOT);
            if (Arrays.asList("of","the","de","da","do","di","del","la").contains(low)) continue;
            if (!(Character.isUpperCase(w.charAt(0)) || w.equals(w.toUpperCase(Locale.ROOT)))) return false;
        }
        return true;
    }

    private static List<String> protectedTerms(List<String> lines, List<Entry> entries) {
        Set<String> set = new HashSet<>();
        for (Entry e : entries) {
            if (KEEP_SECTIONS.contains(e.sec)) {
                String t = lines.get(e.target).trim();
                if (!t.isEmpty() && t.length() <= 80 && WORDISH.matcher(t).find()) set.add(t);
            }
        }
        Collections.addAll(set, "Xenoverse","X Pokémon","PokéWES","Fury Energy","Fury Seal",
                "Pokédex","Pokémon","Mega Evolution","Mega Evolutions","Battle","Move","Moves",
                "Ability","Abilities","Item","Items","Type","Types","TMs","HMs","TM","HM",
                "Poké Ball","Poké Balls");
        List<String> list = new ArrayList<>(set);
        list.sort((a,b) -> Integer.compare(b.length(), a.length()));
        return list;
    }

    private static final class Masked {
        String text; LinkedHashMap<String,String> map;
        Masked(String text, LinkedHashMap<String,String> map) { this.text=text; this.map=map; }
    }

    private static Masked mask(String input, List<String> protectedTerms) {
        LinkedHashMap<String,String> map = new LinkedHashMap<>();
        int[] counter = {0};
        java.util.function.Function<String,String> put = val -> {
            String key = "ZXQKEEP" + String.format(Locale.US, "%04d", counter[0]++) + "QXZ";
            map.put(key, val);
            return key;
        };

        String text = replacePattern(BOLD, input, put);
        text = replacePattern(CONTROL, text, put);

        for (String term : protectedTerms) {
            if (term.length() < 2 || !text.contains(term)) continue;
            Pattern p = Pattern.compile("(?<![A-Za-z0-9À-ÿ])" + Pattern.quote(term) + "(?![A-Za-z0-9À-ÿ])");
            text = replacePattern(p, text, put);
        }
        return new Masked(text, map);
    }

    private static String replacePattern(Pattern p, String src, java.util.function.Function<String,String> fn) {
        Matcher m = p.matcher(src);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(fn.apply(m.group())));
        m.appendTail(sb);
        return sb.toString();
    }

    private static String restore(String text, LinkedHashMap<String,String> map) {
        String out = text;
        for (Map.Entry<String,String> e : map.entrySet()) out = out.replace(e.getKey(), e.getValue());
        return out;
    }

    private static String naturalize(String en, String pt) {
        String[][] pairs = {
                {"ficheiro","arquivo"},{"ficheiros","arquivos"},{"ecrã","tela"},{"Ecrã","Tela"},
                {"telemóvel","celular"},{"Telemóvel","Celular"},{"equipa","equipe"},{"Equipa","Equipe"},
                {"facto","fato"},{"Facto","Fato"},{"contactar","contatar"},{"Contactar","Contatar"}
        };
        for (String[] p : pairs) pt = pt.replace(p[0], p[1]);
        if (!CONTROL.matcher(en).find() && CASUAL.containsKey(en.trim())) return CASUAL.get(en.trim());
        return pt;
    }

    public static Result translate(ContentResolver cr, Uri treeUri, SafFiles.GameFiles gf, Callback cb) throws Exception {
        String english = SafFiles.readText(cr, gf.englishTxt);
        List<String> lines = new ArrayList<>(Arrays.asList(english.split("\\r?\\n", -1)));
        List<String> out = new ArrayList<>(lines);
        List<Entry> entries = parseEntries(lines);
        List<String> protectedTerms = protectedTerms(lines, entries);

        JSONObject cache = new JSONObject();
        Uri cacheUri = SafFiles.findChild(cr, treeUri, gf.dataDir, "ptbr_translation_cache.json");
        if (cacheUri != null) {
            try { cache = new JSONObject(SafFiles.readText(cr, cacheUri)); } catch (Exception ignored) {}
        }

        LinkedHashMap<String,List<Integer>> targets = new LinkedHashMap<>();
        for (Entry e : entries) {
            String target = lines.get(e.target);
            String t = target.trim();
            if (t.isEmpty()) continue;
            if (KEEP_SECTIONS.contains(e.sec) || probableNameOnly(target) || !WORDISH.matcher(target).find()) {
                out.set(e.target, target); continue;
            }
            if (EXACT.containsKey(target)) { out.set(e.target, EXACT.get(target)); continue; }
            if (CASUAL.containsKey(target) && !CONTROL.matcher(target).find()) { out.set(e.target, CASUAL.get(target)); continue; }
            if (cache.has(target)) { out.set(e.target, cache.optString(target, target)); continue; }
            targets.computeIfAbsent(target, k -> new ArrayList<>()).add(e.target);
        }

        List<String> unique = new ArrayList<>(targets.keySet());
        int total = unique.size();
        int done = 0;
        int cursor = 0;

        while (cursor < unique.size()) {
            if (cb.isCancelled()) throw new InterruptedException("Tradução pausada.");

            List<String> batch = new ArrayList<>();
            int chars = 0;
            while (cursor < unique.size() && batch.size() < 14) {
                String s = unique.get(cursor);
                if (!batch.isEmpty() && chars + s.length() > 3600) break;
                batch.add(s); chars += s.length(); cursor++;
            }

            Map<String,String> translated = translateBatch(batch, protectedTerms);
            for (String en : batch) {
                String pt = naturalize(en, translated.getOrDefault(en, en));
                cache.put(en, pt);
                for (Integer idx : targets.get(en)) out.set(idx, pt);
                done++;
            }

            if (done % 70 < batch.size() || done == total) {
                Uri c = SafFiles.getOrCreate(cr, treeUri, gf.dataDir, "application/json", "ptbr_translation_cache.json");
                SafFiles.writeText(cr, c, cache.toString(2));
            }
            cb.onProgress(done, Math.max(total,1), "Traduzindo " + done + " de " + total + " mensagens únicas…");
            Thread.sleep(140);
        }

        // Reaplica o cache também em ocorrências repetidas que não estavam carregadas no output.
        for (Entry e : entries) {
            String target = lines.get(e.target);
            if (cache.has(target) && !KEEP_SECTIONS.contains(e.sec)) out.set(e.target, cache.optString(target, target));
        }

        StringBuilder sb = new StringBuilder(english.length() + 10000);
        for (String line : out) sb.append(line).append('\n');
        return new Result(sb.toString(), cache);
    }

    private static Map<String,String> translateBatch(List<String> batch, List<String> protectedTerms) throws Exception {
        List<Masked> masked = new ArrayList<>();
        StringBuilder joined = new StringBuilder();
        for (int i=0;i<batch.size();i++) {
            Masked m = mask(batch.get(i), protectedTerms);
            masked.add(m);
            if (i>0) joined.append('\n');
            joined.append("ZXQSEG").append(String.format(Locale.US,"%04d",i)).append("QXZ\n").append(m.text);
        }

        String translated = translateNetwork(joined.toString());
        Map<String,String> result = new HashMap<>();
        boolean markersOk = true;
        for (int i=0;i<batch.size();i++) {
            if (!translated.contains("ZXQSEG" + String.format(Locale.US,"%04d",i) + "QXZ")) {
                markersOk = false; break;
            }
        }

        if (!markersOk) {
            for (int i=0;i<batch.size();i++) {
                String t = translateNetwork(masked.get(i).text);
                result.put(batch.get(i), restore(t, masked.get(i).map));
            }
            return result;
        }

        for (int i=0;i<batch.size();i++) {
            String marker = "ZXQSEG" + String.format(Locale.US,"%04d",i) + "QXZ";
            int start = translated.indexOf(marker) + marker.length();
            int end = translated.length();
            if (i+1<batch.size()) {
                String next = "ZXQSEG" + String.format(Locale.US,"%04d",i+1) + "QXZ";
                int p = translated.indexOf(next);
                if (p >= 0) end = p;
            }
            String body = translated.substring(start, end).trim();
            result.put(batch.get(i), restore(body, masked.get(i).map));
        }
        return result;
    }

    private static String translateNetwork(String text) throws Exception {
        Exception last = null;
        for (int attempt=0; attempt<6; attempt++) {
            try {
                String payload = "client=gtx&sl=en&tl=pt&dt=t&q=" +
                        URLEncoder.encode(text, StandardCharsets.UTF_8.name());
                HttpURLConnection c = (HttpURLConnection) new URL(ENDPOINT).openConnection();
                c.setConnectTimeout(25000);
                c.setReadTimeout(45000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Xenoverse-PTBR-App/1.0");
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(payload.getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                StringBuilder response = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line; while ((line=br.readLine())!=null) response.append(line);
                }
                JSONArray root = new JSONArray(response.toString());
                JSONArray parts = root.getJSONArray(0);
                StringBuilder out = new StringBuilder();
                for (int i=0;i<parts.length();i++) {
                    JSONArray p = parts.optJSONArray(i);
                    if (p != null && !p.isNull(0)) out.append(p.optString(0,""));
                }
                if (out.length() > 0) return out.toString();
                throw new Exception("Resposta vazia");
            } catch (Exception e) {
                last = e;
                Thread.sleep(Math.min(30000, 1200L * (1L << attempt)));
            }
        }
        throw new Exception("Falha na tradução pela internet: " + (last != null ? last.getMessage() : "erro desconhecido"));
    }
}
