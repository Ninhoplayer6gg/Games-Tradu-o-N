package com.xenoverseptbr;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

public class TranslationService extends Service {
    public static final String ACTION_START = "com.xenoverseptbr.START";
    public static final String ACTION_CANCEL = "com.xenoverseptbr.CANCEL";
    public static final String ACTION_PROGRESS = "com.xenoverseptbr.PROGRESS";
    private static final String CHANNEL = "translation";
    private static final int NOTIF = 42;

    private volatile boolean cancel = false;
    private volatile boolean running = false;
    private Thread worker;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Tradução do Xenoverse",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_CANCEL.equals(intent.getAction())) {
            cancel = true;
            broadcast(0, "Pausando…", "O progresso já traduzido será preservado no cache.", true);
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || running) return START_NOT_STICKY;

        String tree = intent.getStringExtra("treeUri");
        if (tree == null) { stopSelf(); return START_NOT_STICKY; }

        cancel = false;
        running = true;
        startForeground(NOTIF, notification("Preparando tradução…", 0));

        worker = new Thread(() -> runJob(Uri.parse(tree)), "xenoverse-ptbr");
        worker.start();
        return START_NOT_STICKY;
    }

    private void runJob(Uri treeUri) {
        try {
            ContentResolver cr = getContentResolver();
            broadcast(1, "Validando arquivos…", "Procurando Data/english.txt e Data/Scripts.xvd.", true);
            SafFiles.GameFiles gf = SafFiles.locateGameFiles(cr, treeUri);

            TranslationEngine.Result r = TranslationEngine.translate(cr, treeUri, gf, new TranslationEngine.Callback() {
                @Override public void onProgress(int done, int total, String message) {
                    int pct = total <= 0 ? 5 : Math.min(94, 5 + (int)(89.0 * done / total));
                    broadcast(pct, message, "Pode sair do app. A tradução continua em segundo plano e salva cache.", true);
                    updateNotification(message, pct);
                }
                @Override public boolean isCancelled() { return cancel; }
            });

            if (cancel) throw new InterruptedException("Pausado.");

            broadcast(95, "Gravando portuguese.txt…", "Finalizando os arquivos de idioma.", true);
            Uri pt = SafFiles.getOrCreate(cr, treeUri, gf.dataDir, "text/plain", "portuguese.txt");
            SafFiles.writeText(cr, pt, r.portugueseText);

            Uri cache = SafFiles.getOrCreate(cr, treeUri, gf.dataDir, "application/json", "ptbr_translation_cache.json");
            SafFiles.writeText(cr, cache, r.cache.toString(2));

            if (gf.scriptsXvd == null) throw new Exception("Data/Scripts.xvd não foi encontrado; portuguese.txt foi criado, mas não pude instalar o idioma.");

            Uri backup = SafFiles.findChild(cr, treeUri, gf.dataDir, "Scripts.xvd.ptbr-backup");
            if (backup == null) {
                backup = SafFiles.getOrCreate(cr, treeUri, gf.dataDir, "application/octet-stream", "Scripts.xvd.ptbr-backup");
                SafFiles.copy(cr, gf.scriptsXvd, backup);
            }

            broadcast(97, "Instalando Português (Brasil)…", "Adicionando o idioma ao seletor do jogo.", true);
            byte[] patched = SettingsPatcher.patch(this, SafFiles.readBytes(cr, gf.scriptsXvd));
            SafFiles.writeBytes(cr, gf.scriptsXvd, patched);

            broadcast(100, "Pronto! 🇧🇷",
                    "Abra o Xenoverse e escolha Português (Brasil). Na primeira inicialização, o próprio jogo gera Data/portuguese.dat automaticamente. Moves, Pokémon, Abilities, Items, Types e nomes importantes permanecem em inglês.", false);
            updateNotification("Tradução PT-BR concluída", 100);
        } catch (InterruptedException e) {
            broadcast(0, "Tradução pausada.",
                    "Seu cache foi mantido. Toque em “Traduzir e instalar PT-BR” de novo para continuar.", false);
            updateNotification("Tradução pausada", 0);
        } catch (Exception e) {
            broadcast(0, "Erro", e.getMessage() == null ? e.toString() : e.getMessage(), false);
            updateNotification("Erro na tradução", 0);
        } finally {
            running = false;
            stopForeground(false);
            stopSelf();
        }
    }

    private Notification notification(String text, int pct) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setContentTitle("Xenoverse PT-BR")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(pct < 100)
                .setProgress(100, Math.max(0,pct), pct <= 0)
                .setContentIntent(pi)
                .build();
    }

    private void updateNotification(String text, int pct) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, notification(text,pct));
    }

    private void broadcast(int pct, String status, String detail, boolean isRunning) {
        Intent i = new Intent(ACTION_PROGRESS);
        i.setPackage(getPackageName());
        i.putExtra("percent", pct);
        i.putExtra("status", status);
        i.putExtra("detail", detail);
        i.putExtra("running", isRunning);
        sendBroadcast(i);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
