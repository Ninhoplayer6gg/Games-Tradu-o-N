# XENOVERSE_PTBR_AUTOCOMPILER_V1
# Compila Data/portuguese.txt para Data/portuguese.dat usando o Ruby do próprio jogo.
def __ptbr_denormalize_value(value)
  return value unless value =~ /<<[rnt1\[\]]>>/
  ret=value.dup
  ret.gsub!(/<<1>>/,"\x01")
  ret.gsub!(/<<r>>/,"\r")
  ret.gsub!(/<<n>>/,"\n")
  ret.gsub!(/<<\[>>/,"[")
  ret.gsub!(/<<\]>>/,"]")
  ret.gsub!(/<<t>>/,"\t")
  return ret
end

def __ptbr_compile_text(infile,outfile)
  intldat=[]
  section_name=nil
  section=[]
  flush_section = proc do
    if section_name && section.length>0
      m=/^([Mm][Aa][Pp])?(\d+)$/.match(section_name)
      raise "Invalid section #{section_name}" unless m
      ismap=!!m[1]
      id=m[2].to_i
      if section[0] =~ /^\d+$/
        raise "Map section cannot be ordered list: #{section_name}" if ismap
        raise "Bad ordered section #{section_name}" unless section.length%3==0
        h=[]
        i=0
        while i<section.length
          key=Integer(section[i])
          h[key]=__ptbr_denormalize_value(section[i+2])
          i+=3
        end
      else
        raise "Odd section #{section_name}" unless section.length%2==0
        h={}
        i=0
        while i<section.length
          key=__ptbr_denormalize_value(section[i])
          h[key]=__ptbr_denormalize_value(section[i+1])
          i+=2
        end
      end
      if ismap
        intldat[0] ||= []
        intldat[0][id]=h
      else
        intldat[id]=h
      end
    end
  end

  File.open(infile,'rb') do |file|
    lineno=0
    file.each_line do |line|
      lineno+=1
      line=line.sub(/^\xEF\xBB\xBF/n,'') if lineno==1
      next if line =~ /^\#/ || line =~ /^\s*$/
      line=line.sub(/\s+$/,'')
      if line =~ /^\s*\[\s*([^\]]+)\s*\]\s*$/
        flush_section.call
        section=[]
        section_name=$1
      else
        raise "Expected a section at line #{lineno}" unless section_name
        section << line
      end
    end
  end
  flush_section.call

  File.open(outfile,'wb') { |f| f.write(Marshal.dump(intldat)) }
end

begin
  __ptbr_txt="Data/portuguese.txt"
  __ptbr_dat="Data/portuguese.dat"
  if File.exist?(__ptbr_txt) && (!File.exist?(__ptbr_dat) || File.mtime(__ptbr_txt)>File.mtime(__ptbr_dat))
    __ptbr_compile_text(__ptbr_txt,__ptbr_dat)
  end
rescue Exception => __ptbr_error
  begin
    print "PT-BR compiler: #{__ptbr_error}\n"
  rescue
  end
end
